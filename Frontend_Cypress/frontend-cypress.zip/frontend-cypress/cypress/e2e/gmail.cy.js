describe('Login de Usuario', () => {
  it('loginSucess', () => {
    cy.visit('https://www.gmail.com');
    cy.get('#identifierId').type('angelseb1799@gmail.com');
    cy.get('#identifierNext').click();
  })
})