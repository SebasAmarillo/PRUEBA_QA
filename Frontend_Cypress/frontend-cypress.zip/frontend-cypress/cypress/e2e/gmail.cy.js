describe('Login de Usuario', () => {
  it('loginSucess', () => {
    //VISITAR EL SITIO WEB GMAIL
    cy.visit('https://www.gmail.com');
    //BUSCAR EL PANEL DE INGRESAR EL CORREO Y SETEARLE EL CORREO ELECTRONICO
    cy.get('#identifierId').type('angelseb1799@gmail.com');
    //BUSCAR EL BOTON SIGUIENTE Y DAR CLIC PARA COTINUAR CON EL LOGIN
    cy.get('#identifierNext').click();
  })
})