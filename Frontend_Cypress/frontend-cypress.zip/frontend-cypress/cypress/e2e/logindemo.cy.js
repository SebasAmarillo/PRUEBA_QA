describe('Login de Usuario', () => {
    it('loginSucess', () => {
      //VISITAR EL SITIO WEB ORANGEHRM
      cy.visit('https://opensource-demo.orangehrmlive.com/web/index.php/auth/login');
      //BUSCAR EL PANEL USERNAME Y SETEARLE EL USUARIO
      cy.get('[name="username"]').type('Admin');
      //BUSCAR EL PANEL PASSWORD Y SETEARLE EL PASSWORD
      cy.get('[name="password"]').type('admin123');
      //BUSCAR EL BOTON Y DAR CLIC PARA SU LOGIN
      cy.get('button[type="submit"]').click();
    })
  })