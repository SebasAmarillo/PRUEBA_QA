describe('Login de Usuario', () => {
    it('loginSucess', () => {
      //cy.visit('https://www.mercadolibre.com.co');
      //cy.get('[data-link-id="login"]').click();
      //cy.get('#user_id');
      cy.visit('https://opensource-demo.orangehrmlive.com/web/index.php/auth/login');
      cy.get('[name="username"]').type('Admin');
      cy.get('[name="password"]').type('admin123');
      cy.get('button[type="submit"]').click();
    })
  })